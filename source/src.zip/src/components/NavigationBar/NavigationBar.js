import React from 'react';
import { AppBar, Toolbar, Typography, Button } from '@mui/material';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { Link } from 'react-router-dom';

function NavigationBar() {
  return (
    <AppBar position="static" sx={{ bgcolor: '#3f51b5' }}>
      <Toolbar>
        <ShoppingCartIcon sx={{ mr: 1 }} />
        <Typography 
          variant="h6" 
          sx={{ flexGrow: 1, display: 'flex', alignItems: 'center' }}
        >
          upGrad E-Shop
        </Typography>
        <Button 
          color="inherit" 
          component={Link} 
          to="/login"
          sx={{ textTransform: 'none' }}
        >
          Login
        </Button>
        <Button 
          color="inherit" 
          component={Link} 
          to="/signup"
          sx={{ textTransform: 'none' }}
        >
          Sign Up
        </Button>
      </Toolbar>
    </AppBar>
  );
}

export default NavigationBar;
